/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.48 : Database - club_reservation
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`club_reservation` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `club_reservation`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` varchar(10) NOT NULL,
  `admin_password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`admin_id`,`admin_password`) values ('112233','arun');

/*Table structure for table `booking_info_master` */

DROP TABLE IF EXISTS `booking_info_master`;

CREATE TABLE `booking_info_master` (
  `booking_id` int(20) NOT NULL AUTO_INCREMENT,
  `booking_date_time` date DEFAULT NULL,
  `reservation_date_time` datetime DEFAULT NULL,
  `club_id` varchar(10) DEFAULT NULL,
  `slote_id` int(20) DEFAULT NULL,
  `court_id` int(20) DEFAULT NULL,
  `member_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  KEY `club_id` (`club_id`),
  KEY `slote_id` (`slote_id`),
  KEY `court_id` (`court_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `booking_info_master_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club_info_master` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `booking_info_master_ibfk_2` FOREIGN KEY (`slote_id`) REFERENCES `slote_info_master` (`slote_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `booking_info_master_ibfk_3` FOREIGN KEY (`court_id`) REFERENCES `court_info_master` (`court_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `booking_info_master_ibfk_4` FOREIGN KEY (`member_id`) REFERENCES `member_login` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=latin1;

/*Data for the table `booking_info_master` */

insert  into `booking_info_master`(`booking_id`,`booking_date_time`,`reservation_date_time`,`club_id`,`slote_id`,`court_id`,`member_id`) values (1001,'2017-05-03','2017-05-08 10:00:00','CLU_1',5001,7,'MEM_5');

/*Table structure for table `club_info_master` */

DROP TABLE IF EXISTS `club_info_master`;

CREATE TABLE `club_info_master` (
  `club_id` varchar(10) NOT NULL,
  `club_name` varchar(50) DEFAULT NULL,
  `club_address` varchar(50) DEFAULT NULL,
  `club_password` varchar(50) DEFAULT NULL,
  `club_contact` varchar(50) DEFAULT NULL,
  `director_name` varchar(50) DEFAULT NULL,
  `director_email` varchar(50) DEFAULT NULL,
  `club_openingtime` time DEFAULT NULL,
  `club_closingtime` time DEFAULT NULL,
  `number_of_court` varchar(50) DEFAULT NULL,
  `rec_index` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`club_id`),
  UNIQUE KEY `director_email` (`director_email`),
  KEY `rec_index` (`rec_index`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `club_info_master` */

insert  into `club_info_master`(`club_id`,`club_name`,`club_address`,`club_password`,`club_contact`,`director_name`,`director_email`,`club_openingtime`,`club_closingtime`,`number_of_court`,`rec_index`) values ('CLU_1','tennisport1','indore mp','48414d','9009235618','Arun','arungour200870@gmail.com','10:00:00','06:00:00','4',21),('CLU_3','tennisport5','Hoshangabad','01be3c','9009562418','Mukesh','Mukesh23@gmail.com','10:00:00','06:00:00','4',26),('CLU_4','tennisport1','bhopal saket nagar','2eca86','7898614828','kapil','kapil21@gmail.com','11:00:00','07:00:00','4',27);

/*Table structure for table `court_info_master` */

DROP TABLE IF EXISTS `court_info_master`;

CREATE TABLE `court_info_master` (
  `court_id` int(20) NOT NULL AUTO_INCREMENT,
  `court_name` varchar(50) DEFAULT NULL,
  `court_status` varchar(50) DEFAULT NULL,
  `club_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`court_id`),
  KEY `club_id` (`club_id`),
  CONSTRAINT `court_info_master_ibfk_2` FOREIGN KEY (`club_id`) REFERENCES `club_info_master` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `court_info_master` */

insert  into `court_info_master`(`court_id`,`court_name`,`court_status`,`club_id`) values (6,'BETA_1','Available','CLU_1'),(7,'BETA_2','Available','CLU_1');

/*Table structure for table `member_login` */

DROP TABLE IF EXISTS `member_login`;

CREATE TABLE `member_login` (
  `member_id` varchar(20) NOT NULL,
  `member_name` varchar(20) DEFAULT NULL,
  `member_contact` varchar(11) DEFAULT NULL,
  `member_password` varchar(20) DEFAULT NULL,
  `member_email` varchar(30) DEFAULT NULL,
  `rec_index` int(10) NOT NULL AUTO_INCREMENT,
  `club_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `member_email` (`member_email`),
  KEY `rec_index` (`rec_index`),
  KEY `club_id` (`club_id`),
  CONSTRAINT `member_login_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club_info_master` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;

/*Data for the table `member_login` */

insert  into `member_login`(`member_id`,`member_name`,`member_contact`,`member_password`,`member_email`,`rec_index`,`club_id`) values ('MEM_5','Navin','7898614828','a6040d','ti.navin32@gmail.com',127,'CLU_1'),('MEM_6','Rohit','9009562347','962579','Rohit@gmail.com',128,'CLU_1');

/*Table structure for table `slote_info_master` */

DROP TABLE IF EXISTS `slote_info_master`;

CREATE TABLE `slote_info_master` (
  `slote_id` int(20) NOT NULL AUTO_INCREMENT,
  `slote_start` time DEFAULT NULL,
  `slote_end` time DEFAULT NULL,
  `slote_status` varchar(50) DEFAULT NULL,
  `club_id` varchar(10) DEFAULT NULL,
  `court_id` int(20) DEFAULT NULL,
  PRIMARY KEY (`slote_id`),
  KEY `club_id` (`club_id`),
  KEY `court_id` (`court_id`),
  CONSTRAINT `slote_info_master_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club_info_master` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `slote_info_master_ibfk_2` FOREIGN KEY (`court_id`) REFERENCES `court_info_master` (`court_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5002 DEFAULT CHARSET=latin1;

/*Data for the table `slote_info_master` */

insert  into `slote_info_master`(`slote_id`,`slote_start`,`slote_end`,`slote_status`,`club_id`,`court_id`) values (5001,'10:00:00','11:00:00','Available','CLU_1',6);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
